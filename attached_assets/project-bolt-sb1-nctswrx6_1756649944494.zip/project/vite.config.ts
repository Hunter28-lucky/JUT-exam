import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/api/zapupi': {
        target: 'https://api.zapupi.com',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api\/zapupi/, '')
      }
    }
  },
  optimizeDeps: {
    exclude: ['lucide-react'],
  },
});
